package com.elsonbaty.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Iterator;

public class GameView extends SurfaceView implements Runnable, SurfaceHolder.Callback {
    private Thread thread;
    private boolean running = false;
    private SurfaceHolder holder;
    private Paint paint;
    private ArrayList<Particle> particles = new ArrayList<>();

    public GameView(Context context) {
        super(context);
        holder = getHolder();
        holder.addCallback(this);
        paint = new Paint();
        paint.setAntiAlias(true);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        running = true;
        thread = new Thread(this);
        thread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) { }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        running = false;
        boolean retry = true;
        while (retry) {
            try {
                thread.join();
                retry = false;
            } catch (InterruptedException e) { }
        }
    }

    @Override
    public void run() {
        long lastTime = System.currentTimeMillis();
        while (running) {
            if (!holder.getSurface().isValid()) continue;
            long now = System.currentTimeMillis();
            float delta = (now - lastTime) / 1000f;
            lastTime = now;

            update(delta);
            Canvas canvas = holder.lockCanvas();
            if (canvas != null) {
                drawGame(canvas);
                holder.unlockCanvasAndPost(canvas);
            }

            try { Thread.sleep(16); } catch (InterruptedException e) { }
        }
    }

    private void update(float dt) {
        Iterator<Particle> it = particles.iterator();
        while (it.hasNext()) {
            Particle p = it.next();
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.life -= dt;
            if (p.life <= 0) it.remove();
        }
    }

    private void drawGame(Canvas c) {
        c.drawColor(Color.rgb(20, 24, 30));
        paint.setColor(Color.argb(200, 255, 200, 50));
        paint.setTextSize(40);
        c.drawText("ELSONBATY - Tap to spawn", 50, 80, paint);

        for (Particle p : particles) {
            paint.setColor(p.color);
            c.drawCircle(p.x, p.y, p.radius, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            spawnParticles(event.getX(), event.getY());
            return true;
        }
        return false;
    }

    private void spawnParticles(float x, float y) {
        for (int i = 0; i < 12; i++) {
            Particle p = new Particle();
            p.x = x;
            p.y = y;
            p.vx = (float) (Math.random() * 400 - 200);
            p.vy = (float) (Math.random() * -300 - 50);
            p.radius = (float) (8 + Math.random() * 12);
            p.life = 1.2f + (float)Math.random() * 1.5f;
            p.color = Color.rgb(200 + (int)(Math.random()*55), (int)(Math.random()*200), 50);
            particles.add(p);
        }
    }

    public void pause() {
        running = false;
        boolean retry = true;
        while (retry) {
            try {
                if (thread != null) thread.join();
                retry = false;
            } catch (InterruptedException e) { }
        }
    }

    public void resume() {
        if (!running) {
            running = true;
            thread = new Thread(this);
            thread.start();
        }
    }

    static class Particle {
        float x,y,vx,vy,radius,life;
        int color;
    }
}
